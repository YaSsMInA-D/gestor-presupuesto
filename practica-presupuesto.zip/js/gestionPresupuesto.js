// TODO: Variables globales


// TODO: Funciones adicionales


function actualizarPresupuesto() {
    // TODO
}

function mostrarPresupuesto() {
    // TODO
}

function CrearGasto() {
    // TODO
}

// Exportación de funciones
export   {
    mostrarPresupuesto,
    actualizarPresupuesto,
    CrearGasto
}
